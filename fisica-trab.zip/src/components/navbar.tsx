export const Navbar = () => {
    return (
        <div className="w-full h-15 bg-gradient-to-r from-gray-400 to-white border-b-4 border-solid border-gray-400 flex justify-center items-center">
            <h1>Sistema 2 - Física</h1>
        </div>
    )
}