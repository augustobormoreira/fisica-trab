"use client";
/*length do bloco A + 300
usePulleyNewScene.ts:205 length do bloco B + 200
usePulleyNewScene.ts:217 length do bloco 1 + 245
usePulleyNewScene.ts:217 length do bloco 2 + 290
usePulleyNewScene.ts:217 length do bloco 3 + 335
usePulleyNewScene.ts:217 length do bloco 4 + 380
usePulleyNewScene.ts:217 length do bloco 5 + 425
usePulleyNewScene.ts:217 length do bloco 6 + 470
usePulleyNewScene.ts:197 length do bloco A + 300
usePulleyNewScene.ts:205 length do bloco B + 200
*/
import { Sistema } from "@/types";

export const ManagementPanel = ({
  applyForce,
  resetPositionOfAllBlocks,
  sistemaAtivo,
  onSistemaChange,
  mudaTamanhoCordaEsq,
  paraTamanhoCordaEsq,
}: {
  applyForce: () => void;
  resetPositionOfAllBlocks: () => void;
  sistemaAtivo: Sistema;
  onSistemaChange: (sistema: Sistema) => void;
  mudaTamanhoCordaEsq: (digit: number) => void;
  paraTamanhoCordaEsq: () => void;
}) => {
  return (
    <div className=" flex flex-col items-center w-90 h-auto">
      <div className="flex flex-col w-auto h-10">
        <button
          onClick={() => onSistemaChange("sistema1")}
          className="w-50 h-auto font-serif border-1 rounded-xs border-gray-500 hover:text-white hover:bg-gray-500"
        >
          Sistema 1
        </button>
        <button
          onClick={() => onSistemaChange("sistema2")}
          className="w-50 h-auto font-serif border-1 rounded-xs border-gray-500 hover:text-white hover:bg-gray-500"
        >
          Sistema 2
        </button>
      </div>
      <div className="flex flex-col justify-center items-center w-90 h-90">
        <button className="w-50 h-auto font-serif border-1 rounded-xs border-gray-500 hover:text-white hover:bg-gray-500" onClick={applyForce}>força</button>
        <button className="w-50 h-auto font-serif border-1 rounded-xs border-gray-500 hover:text-white hover:bg-gray-500" onClick={resetPositionOfAllBlocks}>reset posicao</button>
        <button className="w-50 h-auto font-serif border-1 rounded-xs border-gray-500 hover:text-white hover:bg-gray-500" onClick={() => {mudaTamanhoCordaEsq(1)}}>- to left rope</button>
        <button className="w-50 h-auto font-serif border-1 rounded-xs border-gray-500 hover:text-white hover:bg-gray-500" onClick={() => {paraTamanhoCordaEsq()}}>stop to left rope</button>
      </div>
    </div>
  );
};
