import { Body } from "matter-js";

export const BlockModal = ({
  body,
  onClose,
}: {
  body: Matter.Body;
  onClose: () => void;
}) => {
  const handleMassChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    Body.setMass(body, Number(e.target.value));
  };

  const handleFrictionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    body.friction = Number(e.target.value);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="bg-white rounded-0lg shadow-xl p-6 w-80">
        <h2 className="text-xl font-bold mb-4">{body.label}</h2>
        <label className="block text-sm mb-1">Mass</label>
        <input
          type="number"
          defaultValue={body.mass}
          onChange={handleMassChange}
          className="border rounded w-full px-2 py-1 mb-4"
        />

        <label className="block text-sm mb-1">Friction</label>
        <input
          type="number"
          step="0.01"
          defaultValue={body.friction}
          onChange={handleFrictionChange}
          className="border rounded w-full px-2 py-1 mb-4"
        />

        <button onClick={onClose} className="w-full bg-blue-400 text-white rounded py-2">Salvar</button>
      </div>
    </div>
  );
};
