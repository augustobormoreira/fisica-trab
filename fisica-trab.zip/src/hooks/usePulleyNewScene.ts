import { RefObject, useEffect, useRef } from "react";
import {
  Engine,
  Render,
  Runner,
  Bodies,
  Body,
  Composite,
  Events,
  Constraint,
} from "matter-js";

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const PULLEY_LEFT_X = 320;
const PULLEY_RIGHT_X = 780;
const PULLEY_Y = 100;
const PULLEY_RADIUS = 22;
const LEFT_ROPE_INITIAL_LENGTH = 300;
const RIGHT_ROPE_INITIAL_LENGTH = 200;
const BLOCK_A_X_AND_W = 100;
const BLOCK_RIGHT_X_AND_W = 30;

const drawRope = (
  ctx: CanvasRenderingContext2D,
  fromX: number,
  fromY: number,
  toX: number,
  toY: number,
) => {
  ctx.beginPath();
  ctx.moveTo(fromX, fromY);
  ctx.lineTo(toX, toY);
  ctx.strokeStyle = "#5a3a1a";
  ctx.lineWidth = 2;
  ctx.stroke();
};

const createBlock = (
  block_x_position: number,
  block_y_position: number,
  block_width: number,
  block_height: number,
  block_name: string,
) => {
  return Bodies.rectangle(
    block_x_position,
    block_y_position,
    block_width,
    block_height,
    {
      isStatic: false,
      label: block_name,
      render: { fillStyle: "#FFF", strokeStyle: "#000", lineWidth: 1.5 },
    },
  );
};

const nameBlocks = (
  ctx: CanvasRenderingContext2D,
  positionX: number,
  positionY: number,
  blockName: string,
  fontSize: number,
) => {
  ctx.font = `bold ${fontSize}px Arial`;
  ctx.fillStyle = "black";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  ctx.fillText(blockName, positionX, positionY);
};

export const usePulleyNewScene = (
  sceneRef: RefObject<HTMLDivElement | null>,
  rightBlockCount: number,
  leftBlockMass: number,
  rightBlockMass: number,
) => {
  const renderRef = useRef<Render>(null);
  const leftBlockRef = useRef<Body>(null);
  const rightBlocksRef = useRef<Body[]>(null);
  const massesRef = useRef<number[]>(null);
  const leftRopeLengthRef = useRef<number>(300);
  const initialRightRopeLengthRef = useRef<number>(200);
  const remainingRightRopesLengthRef = useRef<number[]>([]);

  useEffect(() => {
    if (!sceneRef.current) return;

    const container = sceneRef.current;
    const containerWidth = container.clientWidth || 1100;
    const containerHeight = container.clientHeight || 800;

    const names = Array.from(
      { length: 1 + rightBlockCount },
      (_, i) => ALPHABET[i],
    );
    const rightTotalMass = rightBlockMass * rightBlockCount;

    massesRef.current = [
      rightTotalMass + 1,
      ...Array(rightBlockCount).fill(rightBlockMass),
    ];
    const engine = Engine.create({
      gravity: { x: 0, y: 0 },
    });

    const render = Render.create({
      element: container,
      engine,
      options: {
        width: containerWidth,
        height: containerHeight,
        wireframes: false,
        background: "#ffffff",
      },
    });
    renderRef.current = render;

    // Block A
    const blockA = createBlock(
      PULLEY_LEFT_X,
      LEFT_ROPE_INITIAL_LENGTH + BLOCK_A_X_AND_W / 2,
      BLOCK_A_X_AND_W,
      BLOCK_A_X_AND_W,
      "A",
    );
    leftBlockRef.current = blockA;

    // Right Blocks
    const rightBlocks: Body[] = [];
    for (let i = 0; i < rightBlockCount; i++) {
      if (i === 0) {
        const newBlock = createBlock(
          PULLEY_RIGHT_X,
          RIGHT_ROPE_INITIAL_LENGTH + BLOCK_RIGHT_X_AND_W / 2,
          BLOCK_RIGHT_X_AND_W,
          BLOCK_RIGHT_X_AND_W,
          names[i + 1],
        );
        rightBlocks.push(newBlock);
      } else {
        const newBlock = createBlock(
          PULLEY_RIGHT_X,
          rightBlocks[i - 1].position.y + 30 + BLOCK_RIGHT_X_AND_W / 2,
          BLOCK_RIGHT_X_AND_W,
          BLOCK_RIGHT_X_AND_W,
          names[i + 1],
        );
        rightBlocks.push(newBlock);
      }
    }
    rightBlocksRef.current = rightBlocks;

    const pulleyLeft = Bodies.circle(PULLEY_LEFT_X, PULLEY_Y, PULLEY_RADIUS, {
      isStatic: true,
      render: { fillStyle: "#aaa", strokeStyle: "#000", lineWidth: 2 },
    });
    const pulleyRight = Bodies.circle(PULLEY_RIGHT_X, PULLEY_Y, PULLEY_RADIUS, {
      isStatic: true,
      render: { fillStyle: "#aaa", strokeStyle: "#000", lineWidth: 2 },
    });
    const bar = Bodies.rectangle(
      (PULLEY_LEFT_X + PULLEY_RIGHT_X) / 2,
      PULLEY_Y - PULLEY_RADIUS - 5,
      PULLEY_RIGHT_X - PULLEY_LEFT_X,
      10,
      {
        isStatic: true,
        render: { fillStyle: "#555", strokeStyle: "#000", lineWidth: 1 },
      },
    );

    Composite.add(engine.world, [
      pulleyLeft,
      pulleyRight,
      bar,
      blockA,
      ...rightBlocks,
    ]);

    Events.on(render, "afterRender", () => {
      const ctx = render.context;
      drawRope(ctx, PULLEY_LEFT_X, PULLEY_Y, PULLEY_RIGHT_X, PULLEY_Y);
      drawRope(
        ctx,
        PULLEY_LEFT_X,
        PULLEY_Y,
        PULLEY_LEFT_X,
        leftRopeLengthRef.current,
      );
      drawRope(
        ctx,
        PULLEY_RIGHT_X,
        PULLEY_Y,
        PULLEY_RIGHT_X,
        initialRightRopeLengthRef.current,
      );
      nameBlocks(ctx, blockA.position.x, blockA.position.y, blockA.label, 40);
      for (let i = 0; i < rightBlockCount; i++) {
        if (i >= 1) {
          drawRope(
            ctx,
            PULLEY_RIGHT_X,
            rightBlocks[i - 1].position.y + BLOCK_RIGHT_X_AND_W / 2,
            PULLEY_RIGHT_X,
            rightBlocks[i].position.y - BLOCK_RIGHT_X_AND_W / 2,
          );
          remainingRightRopesLengthRef.current[i] =
            rightBlocks[i].position.y - BLOCK_RIGHT_X_AND_W / 2;
        }

        nameBlocks(
          ctx,
          rightBlocks[i].position.x,
          rightBlocks[i].position.y,
          rightBlocks[i].label,
          20,
        );
      }
    });

    Render.run(render);
    renderRef.current = render;
    const runner = Runner.create();
    Runner.run(runner, engine);

    const observer = new ResizeObserver(() => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        render.canvas.width = w;
        render.canvas.height = h;
        render.options.width = w;
        render.options.height = h;
        Render.lookAt(render, {
          min: { x: 0, y: 0 },
          max: { x: w, y: h },
        });
      }
    });
    observer.observe(container);

    return () => {
      observer.disconnect();
      Render.stop(render);
      Runner.stop(runner);
      Composite.clear(engine.world, false);
      Engine.clear(engine);
      render.canvas.remove();
    };
  }, [rightBlockCount]);

  function resetPositions() {
    console.log("TO DO");
  }

  const runningRef = useRef(false);

  const startReducingLeftRope = (digit: number) => {
    if (runningRef.current) return;
    runningRef.current = true;

    const loop = () => {
      if (!runningRef.current) return;

      leftRopeLengthRef.current = Math.max(
        0,
        leftRopeLengthRef.current - digit,
      );

      if (leftRopeLengthRef.current === 0) {
        runningRef.current = false;
        return;
      }

      requestAnimationFrame(loop);
    };

    requestAnimationFrame(loop);
  };

  const stopReducingLeftRope = () => {
    runningRef.current = false;
  };

  return {
    resetPositions,
    startReducingLeftRope,
    stopReducingLeftRope,
    leftRopeLengthRef,
    initialRightRopeLengthRef,
    remainingRightRopesLengthRef,
  };
};
