import { RefObject } from "react";
import {
  Engine,
  Render,
  Runner,
  Bodies,
  Composite,
  Events,
  Body,
  Mouse,
  MouseConstraint,
} from "matter-js";
import { useEffect, useRef, useState } from "react";

//type boxsetting definition
type boxSetting = {
  positionX: number;
  positionY: number;
  width: number;
  height: number;
};

//settings of the three boxes defined
const boxSettings = [
  {
    positionX: 200,
    positionY: 700,
    width: 200,
    height: 200,
  },
  {
    positionX: 550,
    positionY: 700,
    width: 100,
    height: 100,
  },
  {
    positionX: 670,
    positionY: 700,
    width: 50,
    height: 50,
  },
];

//function to draw name on blocks
const nameBlocks = (
  ctx: CanvasRenderingContext2D,
  positionX: number,
  positionY: number,
  blockName: string,
) => {
  ctx.font = "bold 40px Arial";
  ctx.fillStyle = "black";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  ctx.fillText(blockName, positionX, positionY);
};

export const useBlocksScene = (sceneRef: RefObject<HTMLDivElement | null>, onBlockClickOpenConfiguration : (body: Matter.Body) => void) => {
  const forcaRef = useRef(false);
  const boxARef = useRef<Body>(null);
  const boxBRef = useRef<Body>(null);
  const boxCRef = useRef<Body>(null);
  const renderRef = useRef<Render>(null);
  const colisaoABRef = useRef(false);
  const colisaoBCRef = useRef(false);
  const onBlockClickRef = useRef(onBlockClickOpenConfiguration)

  useEffect(() => {
    onBlockClickRef.current = onBlockClickOpenConfiguration
  }, [onBlockClickOpenConfiguration])

  //use effect hook that will set up all configuration needed for the engine to behave the way we want to
  //configs will persist on engine main loop
  useEffect(() => {
    if (!sceneRef.current) return;

    //engine
    const engine = Engine.create();

    //renderer
    const render = Render.create({
      element: sceneRef!.current,
      engine: engine,
      options: {
        width: 1100,
        height: 800,
        wireframes: false,
        background: "#ffffff",
      },
    });
    renderRef.current = render;

    //bodies
    const boxA = Bodies.rectangle(
      boxSettings[0].positionX,
      boxSettings[0].positionY,
      boxSettings[0].width,
      boxSettings[0].height,
      {
        label: "Bloco A",
        render: { fillStyle: "#FFF", strokeStyle: "#000", lineWidth: 1 },
      },
    );
    const boxB = Bodies.rectangle(
      boxSettings[1].positionX,
      boxSettings[1].positionY,
      boxSettings[1].width,
      boxSettings[1].height,
      {
        label: "Bloco B",
        render: { fillStyle: "#FFF", strokeStyle: "#000", lineWidth: 1 },
      },
    );
    const boxC = Bodies.rectangle(
      boxSettings[2].positionX,
      boxSettings[2].positionY,
      boxSettings[2].width,
      boxSettings[2].height,
      {
        label: "Bloco C",
        render: { fillStyle: "#FFF", strokeStyle: "#000", lineWidth: 1 },
      },
    );

    //set up box refs to be used outside of useeffect hook
    boxARef.current = boxA;
    boxBRef.current = boxB;
    boxCRef.current = boxC;

    //ground rectangle
    const ground = Bodies.rectangle(550, 710, 1000, 60, { isStatic: true });

    const mouse = Mouse.create(render.canvas);
    const mouseConstraint = MouseConstraint.create(engine, { mouse });
    Composite.add(engine.world, mouseConstraint);

    //add to world
    Composite.add(engine.world, [boxA, boxB, boxC, ground]);

    // write arrow
    Events.on(render, "afterRender", () => {
      //name blocks
      const ctx = render.context;
      nameBlocks(ctx, boxA.position.x, boxA.position.y, "A");
      nameBlocks(ctx, boxB.position.x, boxB.position.y, "B");
      nameBlocks(ctx, boxC.position.x, boxC.position.y, "C");

      //draw force proposed by professor
      drawForceOnBlock(
        boxA.position.x,
        boxA.position.y,
        boxSettings[0].width,
        "F",
        boxSettings[0].width,
        "red",
        false,
      );

      if (forcaRef.current) {
        //draw forces that should appear after block B start moving
        if (colisaoABRef.current) {
          //draw force that A exerts on B
          drawForceOnBlock(
            boxB.position.x,
            boxB.position.y,
            boxSettings[1].width,
            "Fab",
            boxSettings[1].width,
            "red",
            false,
          );

          //draw force that B exerts on A
          drawForceOnBlock(
            boxA.position.x - boxSettings[1].width,
            boxA.position.y,
            boxSettings[1].width,
            "Fba",
            boxSettings[1].width,
            "blue",
            true,
          );

          //B friction
          drawForceOnBlock(
            boxB.position.x - boxSettings[1].width / 2,
            boxB.position.y + boxSettings[1].height / 2,
            boxSettings[1].width,
            "atr b",
            boxSettings[1].width / 2,
            "green",
            true,
          );
        }

        if (colisaoBCRef.current) {
          //draw forces that should appear on C after it starts moving
          //draw force that B exerts on C
          drawForceOnBlock(
            boxC.position.x,
            boxC.position.y,
            boxSettings[2].width,
            "Fbc",
            boxSettings[2].width,
            "red",
            false,
          );

          //draw force that C exerts on B
          drawForceOnBlock(
            boxB.position.x - boxSettings[2].width,
            boxB.position.y,
            boxSettings[2].width,
            "Fcb",
            boxSettings[2].width,
            "blue",
            true,
          );

          //C friction
          drawForceOnBlock(
            boxC.position.x - boxSettings[2].width / 2,
            boxC.position.y + boxSettings[2].height / 2,
            boxSettings[2].width,
            "atr c",
            boxSettings[2].width / 2,
            "green",
            true,
          );
        }

        //draw A friction
        drawForceOnBlock(
          boxA.position.x - boxSettings[0].width / 2,
          boxA.position.y + boxSettings[0].height / 2,
          boxSettings[0].width,
          "atr a",
          boxSettings[0].width / 2,
          "green",
          true,
        );
      }
    });

    //event listener for when button pressed, force starts exerting on A
    Events.on(engine, "afterUpdate", () => {
      if (forcaRef.current) {
        Body.applyForce(boxA, boxA.position, { x: 0.008, y: 0 });
      }
    });

    //event listener to check for collision by blocks A and B , and B and C
    Events.on(engine, "collisionStart", (event) => {
      event.pairs.forEach((pair) => {
        const { bodyA, bodyB } = pair;

        const colisaoAB =
          (bodyA === boxA && bodyB === boxB) ||
          (bodyA === boxB && bodyB === boxA);

        const colisaoBC =
          (bodyA === boxB && bodyB === boxC) ||
          (bodyA === boxC && bodyB === boxB);

        if (colisaoAB) {
          colisaoABRef.current = true;
        }
        if (colisaoBC) {
          colisaoBCRef.current = true;
        }
      });
    });

    Events.on(mouseConstraint, "mousedown", (event) => {
      const clickedBody = event.source.body
      if (clickedBody && !clickedBody.isStatic){
        onBlockClickRef.current(clickedBody)
      }
    })
    

    //run render
    Render.run(render);

    // runner
    const runner = Runner.create();

    Runner.run(runner, engine);

    //cleanup
    return () => {
      Render.stop(render);
      Runner.stop(runner);

      Composite.clear(engine.world, false);

      Engine.clear(engine);

      render.canvas.remove();
    };
  }, []);

  //function to draw forces on blocks
  const drawForceOnBlock = (
    positionX: number,
    positionY: number,
    boxWidth: number,
    forceText: string,
    arrowSize: number,
    colorArrow: string,
    isReverseArrow: boolean,
  ) => {
    const ctx = renderRef.current!.context;

    const leftSideOfBox = positionX;
    const arrowY = positionY;

    // linha
    ctx.beginPath();

    ctx.moveTo(leftSideOfBox + arrowSize, arrowY);

    ctx.lineTo(leftSideOfBox, arrowY);

    ctx.strokeStyle = colorArrow;
    ctx.lineWidth = 4;
    ctx.stroke();

    // ponta
    if (!isReverseArrow) {
      ctx.beginPath();

      const newLeftSideofBox = leftSideOfBox + arrowSize;

      ctx.moveTo(newLeftSideofBox + 3, arrowY);

      ctx.lineTo(newLeftSideofBox - 15, arrowY - 10);

      ctx.lineTo(newLeftSideofBox - 15, arrowY + 10);

      ctx.closePath();

      ctx.fillStyle = colorArrow;
      ctx.fill();
    } else {
      ctx.beginPath();

      const newLeftSideOfBox = positionX;

      ctx.moveTo(newLeftSideOfBox - 3, arrowY);

      ctx.lineTo(newLeftSideOfBox + 15, arrowY + 10);

      ctx.lineTo(newLeftSideOfBox + 15, arrowY - 10);

      ctx.closePath();

      ctx.fillStyle = colorArrow;
      ctx.fill();
    }

    // texto
    ctx.font = "24px Arial";
    ctx.fillStyle = "black";

    ctx.fillText(forceText, leftSideOfBox + 35, arrowY - 15);
  };

  //function to reset all blocks positions and colision references once button pressed
  const resetPositionOfAllBlocks = () => {
    forcaRef.current = false;
    colisaoABRef.current = false;
    colisaoBCRef.current = false;
    resetPosition(boxARef.current!, boxSettings[0].positionX);
    resetPosition(boxBRef.current!, boxSettings[1].positionX);
    resetPosition(boxCRef.current!, boxSettings[2].positionX);
  };

  //function to reset specific block position
  const resetPosition = (boxRef: Body, x_position: number) => {
    Body.setVelocity(boxRef, { x: 0, y: 0 });
    Body.setAngularVelocity(boxRef, 0);
    Body.setPosition(boxRef, { x: x_position, y: 700 });
  };

  const applyForce = () => {
    forcaRef.current = true
  }

  return { resetPositionOfAllBlocks, applyForce }
};
