"use client";
import { Scenario } from "@/components/scenario";
import { ManagementPanel } from "@/components/managementPanel";
import { useRef, useState, useCallback } from "react";
import { useBlocksScene } from "@/hooks/useBlocksScene";
import { Sistema } from "@/types";
import Matter from "matter-js";
import { usePulleyNewScene } from "@/hooks/usePulleyNewScene";
import { BlockModal } from "@/components/blockModal";

export default function Home() {
  const sceneRef1 = useRef<HTMLDivElement>(null);
  const sceneRef2 = useRef<HTMLDivElement>(null);
  const [selectedBody, setSelectedBody] = useState<Matter.Body | null>(null);

  const handleBlockClick = useCallback((body: Matter.Body) => {
    setSelectedBody(body);
  }, []);

  const { applyForce, resetPositionOfAllBlocks } = useBlocksScene(
    sceneRef1,
    handleBlockClick,
  );
  const { resetPositions, startReducingLeftRope, stopReducingLeftRope } = usePulleyNewScene(sceneRef2, 7, 10, 9);
  const [sistemaAtivo, setSistemaAtivo] = useState<Sistema>("sistema1");

  return (
    <div className="w-full h-full flex flex-row overflow-hidden">

      <div className="w-64 shrink-0 h-full border-r border-gray-300 flex items-start pt-4 justify-center">
        <ManagementPanel
          applyForce={applyForce}
          resetPositionOfAllBlocks={resetPositionOfAllBlocks}
          sistemaAtivo={sistemaAtivo}
          onSistemaChange={setSistemaAtivo}
          mudaTamanhoCordaEsq={startReducingLeftRope}
          paraTamanhoCordaEsq={stopReducingLeftRope}
        />
      </div>

      <div className="flex-1 h-full relative overflow-hidden">

        <div
          className={`absolute inset-0 ${
            sistemaAtivo === "sistema1" ? "block" : "hidden"
          }`}
        >
          <Scenario sceneRef={sceneRef1} />
        </div>

        <div
          className={`absolute inset-0 ${
            sistemaAtivo === "sistema2" ? "block" : "hidden"
          }`}
        >
          <Scenario sceneRef={sceneRef2} />
        </div>
      </div>

      {selectedBody && (
        <BlockModal body={selectedBody} onClose={() => setSelectedBody(null)} />
      )}
    </div>
  );
}
